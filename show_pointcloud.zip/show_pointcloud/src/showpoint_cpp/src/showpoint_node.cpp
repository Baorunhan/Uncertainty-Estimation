#include "rclcpp/rclcpp.hpp"
#include <opencv2/opencv.hpp>
#include <opencv2/core/ocl.hpp>
#include <iostream>
#include "point_publish.h"

using namespace cv;
using namespace std;

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  // auto node = rclcpp::Node::make_shared("helloworld_node");
  // RCLCPP_INFO(node->get_logger(), "Hello World111!");
  // rclcpp::shutdown();
  // // PLC 库调用示例
  // createBasicPointCloud();
  // 发布一个节点
  auto node = std::make_shared<PointCloudPublisher>();
  rclcpp::spin(node);
  rclcpp::shutdown();

  return 0;
}